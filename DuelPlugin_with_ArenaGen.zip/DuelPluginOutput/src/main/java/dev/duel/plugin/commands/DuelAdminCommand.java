package dev.duel.plugin.commands;

import dev.duel.plugin.DuelPlugin;
import dev.duel.plugin.arena.Arena;
import dev.duel.plugin.arena.ArenaGenerator;
import dev.duel.plugin.util.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.Map;

public class DuelAdminCommand implements CommandExecutor {
    private final DuelPlugin plugin;

    public DuelAdminCommand(DuelPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("duel.admin")) {
            MessageUtil.send(sender, "&cNo permission.");
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {

            case "setarena" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("In-game only."); return true; }
                if (args.length < 2) { MessageUtil.send(sender, "&7Usage: &e/dueladmin setarena <n>"); return true; }
                String name = args[1];
                Arena existing = plugin.getArenaManager().getArena(name);
                if (existing == null) {
                    plugin.getArenaManager().createArena(name, player.getLocation(), player.getLocation());
                    MessageUtil.send(player, "&aCreated arena &e" + name + "&a. Now set spawn1 and spawn2 with:");
                    MessageUtil.sendRaw(player, "  &e/dueladmin setspawn1 " + name + " &7and &e/dueladmin setspawn2 " + name);
                } else {
                    MessageUtil.send(player, "&cArena &e" + name + " &calready exists.");
                }
            }

            case "generatearena" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("In-game only."); return true; }
                if (args.length < 2) {
                    MessageUtil.send(sender, "&7Usage: &e/dueladmin generatearena <n> [style]");
                    MessageUtil.send(sender, "&7Styles: &eclassic, nether, ice, sand, obsidian, sky");
                    return true;
                }
                String arenaName = args[1].toLowerCase();
                if (plugin.getArenaManager().getArena(arenaName) != null) {
                    MessageUtil.send(player, "&cArena &e" + arenaName + " &calready exists. Delete it first.");
                    return true;
                }
                ArenaGenerator.Style style = args.length >= 3
                        ? ArenaGenerator.parseStyle(args[2])
                        : ArenaGenerator.Style.CLASSIC;

                MessageUtil.send(player, "&7Generating arena &e" + arenaName
                        + " &7(style: &b" + style.name().toLowerCase() + "&7)...");

                ArenaGenerator.ArenaResult result = ArenaGenerator.generate(player.getLocation(), style);
                if (result == null) {
                    MessageUtil.send(player, "&cFailed to generate arena - invalid world.");
                    return true;
                }
                plugin.getArenaManager().createArena(arenaName, result.spawn1(), result.spawn2());
                MessageUtil.send(player, "&aArena &e" + arenaName + " &abuilt successfully!");
                MessageUtil.sendRaw(player, "&7Spawns set automatically. Use &e/dueladmin setspawn1/setspawn2 &7to fine-tune.");
            }

            case "liststyles" -> {
                MessageUtil.sendRaw(sender, "&8&m------- &b&lArena Styles &8&m-------");
                MessageUtil.sendRaw(sender, "  &eclassic  &7- Stone bricks, neutral PvP");
                MessageUtil.sendRaw(sender, "  &cnether   &7- Nether bricks, dark theme");
                MessageUtil.sendRaw(sender, "  &bice      &7- Packed ice floor");
                MessageUtil.sendRaw(sender, "  &6sand     &7- Sandstone, desert arena");
                MessageUtil.sendRaw(sender, "  &5obsidian &7- Obsidian + purpur, prestige");
                MessageUtil.sendRaw(sender, "  &fsky      &7- End stone, floating island");
                MessageUtil.sendRaw(sender, "&7Usage: &e/dueladmin generatearena <n> <style>");
            }

            case "setspawn1" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("In-game only."); return true; }
                if (args.length < 2) { MessageUtil.send(sender, "&7Usage: &e/dueladmin setspawn1 <n>"); return true; }
                Arena arena = plugin.getArenaManager().getArena(args[1]);
                if (arena == null) { MessageUtil.send(player, "&cArena not found."); return true; }
                arena.setSpawn1(player.getLocation().clone());
                plugin.getArenaManager().saveArenas();
                MessageUtil.send(player, "&aSpawn 1 set for arena &e" + args[1]);
            }

            case "setspawn2" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("In-game only."); return true; }
                if (args.length < 2) { MessageUtil.send(sender, "&7Usage: &e/dueladmin setspawn2 <n>"); return true; }
                Arena arena = plugin.getArenaManager().getArena(args[1]);
                if (arena == null) { MessageUtil.send(player, "&cArena not found."); return true; }
                arena.setSpawn2(player.getLocation().clone());
                plugin.getArenaManager().saveArenas();
                MessageUtil.send(player, "&aSpawn 2 set for arena &e" + args[1]);
            }

            case "deletearena" -> {
                if (args.length < 2) { MessageUtil.send(sender, "&7Usage: &e/dueladmin deletearena <n>"); return true; }
                if (plugin.getArenaManager().getArena(args[1]) == null) {
                    MessageUtil.send(sender, "&cArena not found.");
                } else {
                    plugin.getArenaManager().deleteArena(args[1]);
                    MessageUtil.send(sender, "&aDeleted arena &e" + args[1]);
                }
            }

            case "listarenas" -> {
                Map<String, Arena> arenas = plugin.getArenaManager().getArenas();
                if (arenas.isEmpty()) {
                    MessageUtil.send(sender, "&7No arenas created yet. Use &e/dueladmin generatearena <n>");
                    return true;
                }
                MessageUtil.sendRaw(sender, "&8&m------- &c&lArenas &8&m-------");
                for (Arena a : arenas.values()) {
                    String status = a.isInUse() ? "&c[IN USE]" : "&a[AVAILABLE]";
                    String valid = a.isValid() ? "&a\u2714" : "&c\u2718 (needs spawns)";
                    MessageUtil.sendRaw(sender, "  &e" + a.getName() + " " + status + " " + valid);
                }
            }

            case "reload" -> {
                plugin.reloadConfig();
                MessageUtil.send(sender, "&aConfig reloaded.");
            }

            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        MessageUtil.sendRaw(sender, "&8&m------- &c&lDuelAdmin Help &8&m-------");
        MessageUtil.sendRaw(sender, "  &e/dueladmin generatearena <n> [s] &7- Auto-build arena in-world");
        MessageUtil.sendRaw(sender, "  &e/dueladmin liststyles            &7- Show available styles");
        MessageUtil.sendRaw(sender, "  &e/dueladmin setarena <n>         &7- Create arena (manual)");
        MessageUtil.sendRaw(sender, "  &e/dueladmin setspawn1/2 <n>      &7- Set spawn points");
        MessageUtil.sendRaw(sender, "  &e/dueladmin deletearena <n>      &7- Delete arena");
        MessageUtil.sendRaw(sender, "  &e/dueladmin listarenas           &7- List all arenas");
        MessageUtil.sendRaw(sender, "  &e/dueladmin reload               &7- Reload config");
    }
}
