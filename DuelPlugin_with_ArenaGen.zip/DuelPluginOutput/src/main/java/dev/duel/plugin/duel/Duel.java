package dev.duel.plugin.duel;

import dev.duel.plugin.arena.Arena;
import dev.duel.plugin.kit.KitType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class Duel {

    public enum State { STARTING, ACTIVE, ENDING }

    private final UUID player1;
    private final UUID player2;
    private final KitType kit;
    private final Arena arena;
    private State state;

    private ItemStack[] player1Inventory;
    private ItemStack[] player1Armor;
    private ItemStack[] player2Inventory;
    private ItemStack[] player2Armor;

    private org.bukkit.Location player1Return;
    private org.bukkit.Location player2Return;

    private final long startTime;
    private final Set<UUID> spectators = new HashSet<>();

    private int player1Hits = 0;
    private int player2Hits = 0;

    public Duel(Player p1, Player p2, KitType kit, Arena arena) {
        this.player1 = p1.getUniqueId();
        this.player2 = p2.getUniqueId();
        this.kit = kit;
        this.arena = arena;
        this.state = State.STARTING;
        this.startTime = System.currentTimeMillis();

        // Save return locations
        this.player1Return = p1.getLocation().clone();
        this.player2Return = p2.getLocation().clone();

        // Save inventories
        this.player1Inventory = p1.getInventory().getContents().clone();
        this.player1Armor = p1.getInventory().getArmorContents().clone();
        this.player2Inventory = p2.getInventory().getContents().clone();
        this.player2Armor = p2.getInventory().getArmorContents().clone();
    }

    public UUID getPlayer1() { return player1; }
    public UUID getPlayer2() { return player2; }
    public KitType getKit() { return kit; }
    public Arena getArena() { return arena; }
    public State getState() { return state; }
    public void setState(State state) { this.state = state; }
    public long getStartTime() { return startTime; }
    public Set<UUID> getSpectators() { return spectators; }

    public ItemStack[] getPlayer1Inventory() { return player1Inventory; }
    public ItemStack[] getPlayer1Armor() { return player1Armor; }
    public ItemStack[] getPlayer2Inventory() { return player2Inventory; }
    public ItemStack[] getPlayer2Armor() { return player2Armor; }
    public org.bukkit.Location getPlayer1Return() { return player1Return; }
    public org.bukkit.Location getPlayer2Return() { return player2Return; }

    public boolean involves(UUID uuid) {
        return player1.equals(uuid) || player2.equals(uuid);
    }

    public UUID getOpponent(UUID uuid) {
        return player1.equals(uuid) ? player2 : player1;
    }

    public void addSpectator(UUID uuid) { spectators.add(uuid); }
    public void removeSpectator(UUID uuid) { spectators.remove(uuid); }

    public void registerHit(UUID attacker) {
        if (attacker.equals(player1)) player1Hits++;
        else if (attacker.equals(player2)) player2Hits++;
    }

    public int getHits(UUID uuid) {
        if (uuid.equals(player1)) return player1Hits;
        return player2Hits;
    }

    public long getDurationMillis() {
        return System.currentTimeMillis() - startTime;
    }
}
