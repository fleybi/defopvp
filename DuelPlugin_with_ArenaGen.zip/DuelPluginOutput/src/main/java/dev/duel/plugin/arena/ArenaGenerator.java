package dev.duel.plugin.arena;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

import java.util.Random;

/**
 * Generates duel arenas in-world using Bukkit block API.
 * No WorldEdit required — works on any Paper 1.21+ server.
 *
 * Usage: /dueladmin generatearena <name> [style]
 * Styles: classic, nether, ice, sand, obsidian, sky
 */
public class ArenaGenerator {

    public enum Style {
        CLASSIC,   // Stone bricks + grass — neutral competitive
        NETHER,    // Nether bricks + magma — dark & aggressive
        ICE,       // Packed ice + snow — slippery edges
        SAND,      // Sandstone — desert vibe
        OBSIDIAN,  // Obsidian + purpur — prestige / ranked
        SKY        // End stone + glass floor — floating island
    }

    private static final int PLATFORM_RADIUS = 12;   // 25x25 arena
    private static final int WALL_HEIGHT     = 4;    // Wall height above floor
    private static final int SPAWN_OFFSET    = 8;    // Distance from center to spawn

    /**
     * Generates an arena centered at the given location.
     * @return ArenaResult with spawn1 and spawn2 Locations, or null on failure
     */
    public static ArenaResult generate(Location center, Style style) {
        World world = center.getWorld();
        if (world == null) return null;

        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();

        StyleMaterials mat = getMaterials(style);

        // 1. Clear the space (air above + 1 below)
        for (int x = -PLATFORM_RADIUS - 1; x <= PLATFORM_RADIUS + 1; x++) {
            for (int z = -PLATFORM_RADIUS - 1; z <= PLATFORM_RADIUS + 1; z++) {
                for (int y = 0; y <= WALL_HEIGHT + 2; y++) {
                    world.getBlockAt(cx + x, cy + y, cz + z).setType(Material.AIR);
                }
                // Clear 1 block below floor too
                world.getBlockAt(cx + x, cy - 1, cz + z).setType(Material.AIR);
            }
        }

        // 2. Place floor
        for (int x = -PLATFORM_RADIUS; x <= PLATFORM_RADIUS; x++) {
            for (int z = -PLATFORM_RADIUS; z <= PLATFORM_RADIUS; z++) {
                Block floor = world.getBlockAt(cx + x, cy, cz + z);
                // Checkerboard accent pattern in center
                boolean isCenter = Math.abs(x) <= 2 && Math.abs(z) <= 2;
                if (isCenter && (x + z) % 2 == 0) {
                    floor.setType(mat.floorAccent);
                } else {
                    floor.setType(mat.floor);
                }
            }
        }

        // 3. Place walls
        for (int x = -PLATFORM_RADIUS; x <= PLATFORM_RADIUS; x++) {
            for (int z = -PLATFORM_RADIUS; z <= PLATFORM_RADIUS; z++) {
                boolean onEdge = Math.abs(x) == PLATFORM_RADIUS || Math.abs(z) == PLATFORM_RADIUS;
                if (!onEdge) continue;
                for (int y = 1; y <= WALL_HEIGHT; y++) {
                    Block wall = world.getBlockAt(cx + x, cy + y, cz + z);
                    // Top row is different material for visual flair
                    wall.setType(y == WALL_HEIGHT ? mat.wallTop : mat.wall);
                }
            }
        }

        // 4. Place corner pillars (decorative)
        for (int dx : new int[]{-PLATFORM_RADIUS, PLATFORM_RADIUS}) {
            for (int dz : new int[]{-PLATFORM_RADIUS, PLATFORM_RADIUS}) {
                for (int y = 1; y <= WALL_HEIGHT + 1; y++) {
                    world.getBlockAt(cx + dx, cy + y, cz + dz).setType(mat.pillar);
                }
            }
        }

        // 5. Place light sources so arena isn't dark
        placeLights(world, cx, cy, cz, mat.light);

        // 6. Compute spawns (facing each other)
        Location spawn1 = new Location(world,
                cx - SPAWN_OFFSET + 0.5, cy + 1, cz + 0.5,
                90f, 0f);   // facing +X
        Location spawn2 = new Location(world,
                cx + SPAWN_OFFSET + 0.5, cy + 1, cz + 0.5,
                -90f, 0f);  // facing -X

        return new ArenaResult(spawn1, spawn2);
    }

    private static void placeLights(World world, int cx, int cy, int cz, Material light) {
        // 4 lights embedded in floor near corners
        int[] offsets = {-8, 8};
        for (int dx : offsets) {
            for (int dz : offsets) {
                world.getBlockAt(cx + dx, cy, cz + dz).setType(light);
            }
        }
    }

    private static StyleMaterials getMaterials(Style style) {
        return switch (style) {
            case CLASSIC -> new StyleMaterials(
                    Material.STONE_BRICKS,
                    Material.CRACKED_STONE_BRICKS,
                    Material.STONE_BRICK_WALL,
                    Material.MOSSY_STONE_BRICKS,
                    Material.CHISELED_STONE_BRICKS,
                    Material.GLOWSTONE
            );
            case NETHER -> new StyleMaterials(
                    Material.NETHER_BRICKS,
                    Material.CRACKED_NETHER_BRICKS,
                    Material.NETHER_BRICK_WALL,
                    Material.RED_NETHER_BRICKS,
                    Material.CHISELED_NETHER_BRICKS,
                    Material.SHROOMLIGHT
            );
            case ICE -> new StyleMaterials(
                    Material.PACKED_ICE,
                    Material.BLUE_ICE,
                    Material.LIGHT_BLUE_STAINED_GLASS,
                    Material.ICE,
                    Material.FROSTED_ICE,
                    Material.SEA_LANTERN
            );
            case SAND -> new StyleMaterials(
                    Material.SANDSTONE,
                    Material.CHISELED_SANDSTONE,
                    Material.SANDSTONE_WALL,
                    Material.CUT_SANDSTONE,
                    Material.SMOOTH_SANDSTONE,
                    Material.GLOWSTONE
            );
            case OBSIDIAN -> new StyleMaterials(
                    Material.OBSIDIAN,
                    Material.PURPUR_BLOCK,
                    Material.OBSIDIAN,
                    Material.CRYING_OBSIDIAN,
                    Material.PURPUR_PILLAR,
                    Material.END_ROD
            );
            case SKY -> new StyleMaterials(
                    Material.END_STONE_BRICKS,
                    Material.GLASS,
                    Material.END_STONE_BRICK_WALL,
                    Material.END_STONE,
                    Material.PURPUR_SLAB,
                    Material.SEA_LANTERN
            );
        };
    }

    public static Style parseStyle(String s) {
        if (s == null) return Style.CLASSIC;
        return switch (s.toLowerCase()) {
            case "nether"   -> Style.NETHER;
            case "ice"      -> Style.ICE;
            case "sand"     -> Style.SAND;
            case "obsidian" -> Style.OBSIDIAN;
            case "sky"      -> Style.SKY;
            default         -> Style.CLASSIC;
        };
    }

    // ---- Inner records ----

    private record StyleMaterials(
            Material floor,
            Material floorAccent,
            Material wall,
            Material wallTop,
            Material pillar,
            Material light
    ) {}

    public record ArenaResult(Location spawn1, Location spawn2) {}
}
