package dev.duel.plugin.commands;

import dev.duel.plugin.DuelPlugin;
import dev.duel.plugin.kit.KitType;
import dev.duel.plugin.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public class DuelCommand implements CommandExecutor {

    private final DuelPlugin plugin;

    public DuelCommand(DuelPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            MessageUtil.send(player, "&cPlayer &e" + args[0] + " &cnot found.");
            return true;
        }
        if (target.equals(player)) {
            MessageUtil.send(player, "&cYou can't duel yourself!");
            return true;
        }

        KitType kit = KitType.NODEBUFF;
        if (args.length >= 2) {
            kit = KitType.fromString(args[1]);
            if (kit == null) {
                MessageUtil.send(player, "&cUnknown kit. Available: &e" + getKitList());
                return true;
            }
        } else {
            // Open kit selector
            openKitMenu(player, target);
            return true;
        }

        plugin.getDuelManager().sendRequest(player, target, kit);
        return true;
    }

    private void openKitMenu(Player player, Player target) {
        // Simple text-based kit selection
        MessageUtil.send(player, "&7Select a kit for your duel vs &e" + target.getName() + "&7:");
        List<KitType> kits = plugin.getKitManager().getEnabledKits();
        StringBuilder sb = new StringBuilder();
        for (KitType kit : kits) {
            sb.append(kit.getDisplayName()).append(" &8[&7/duel ").append(target.getName()).append(" ").append(kit.getId()).append("&8] ");
        }
        MessageUtil.sendRaw(player, "  " + sb);
    }

    private void sendHelp(Player player) {
        MessageUtil.send(player, "&7Usage: &e/duel <player> [kit]");
        MessageUtil.sendRaw(player, "  &7Available kits: &e" + getKitList());
    }

    private String getKitList() {
        StringBuilder sb = new StringBuilder();
        for (KitType kit : plugin.getKitManager().getEnabledKits()) {
            if (sb.length() > 0) sb.append("&7, ");
            sb.append(kit.getDisplayName());
        }
        return sb.toString();
    }
}
