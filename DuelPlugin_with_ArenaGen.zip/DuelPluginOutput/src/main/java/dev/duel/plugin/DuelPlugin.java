package dev.duel.plugin;

import dev.duel.plugin.arena.ArenaManager;
import dev.duel.plugin.commands.*;
import dev.duel.plugin.duel.DuelManager;
import dev.duel.plugin.kit.KitManager;
import dev.duel.plugin.listeners.*;
import dev.duel.plugin.queue.QueueManager;
import dev.duel.plugin.stats.StatsManager;
import dev.duel.plugin.util.MessageUtil;
import org.bukkit.plugin.java.JavaPlugin;

public final class DuelPlugin extends JavaPlugin {

    private static DuelPlugin instance;

    private DuelManager duelManager;
    private ArenaManager arenaManager;
    private KitManager kitManager;
    private QueueManager queueManager;
    private StatsManager statsManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();
        MessageUtil.init(this);

        // Init managers
        this.kitManager = new KitManager(this);
        this.arenaManager = new ArenaManager(this);
        this.statsManager = new StatsManager(this);
        this.duelManager = new DuelManager(this);
        this.queueManager = new QueueManager(this);

        // Register commands
        getCommand("duel").setExecutor(new DuelCommand(this));
        getCommand("duelaccept").setExecutor(new DuelAcceptCommand(this));
        getCommand("dueldeny").setExecutor(new DuelDenyCommand(this));
        getCommand("queue").setExecutor(new QueueCommand(this));
        getCommand("leavequeue").setExecutor(new LeaveQueueCommand(this));
        getCommand("duelstats").setExecutor(new DuelStatsCommand(this));
        getCommand("dueladmin").setExecutor(new DuelAdminCommand(this));
        getCommand("spectate").setExecutor(new SpectateCommand(this));

        // Register listeners
        getServer().getPluginManager().registerEvents(new DuelListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new InventoryListener(this), this);

        getLogger().info("DuelPlugin enabled! Made for Paper 1.21+");
    }

    @Override
    public void onDisable() {
        if (duelManager != null) duelManager.endAllDuels();
        if (statsManager != null) statsManager.saveAll();
        getLogger().info("DuelPlugin disabled.");
    }

    public static DuelPlugin getInstance() { return instance; }
    public DuelManager getDuelManager() { return duelManager; }
    public ArenaManager getArenaManager() { return arenaManager; }
    public KitManager getKitManager() { return kitManager; }
    public QueueManager getQueueManager() { return queueManager; }
    public StatsManager getStatsManager() { return statsManager; }
}
