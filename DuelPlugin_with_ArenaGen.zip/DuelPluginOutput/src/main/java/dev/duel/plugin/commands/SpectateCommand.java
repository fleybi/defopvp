package dev.duel.plugin.commands;

import dev.duel.plugin.DuelPlugin;
import dev.duel.plugin.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class SpectateCommand implements CommandExecutor {
    private final DuelPlugin plugin;
    public SpectateCommand(DuelPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;
        if (args.length == 0) {
            MessageUtil.send(player, "&7Usage: &e/spectate <player>");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            MessageUtil.send(player, "&cPlayer not found.");
            return true;
        }
        plugin.getDuelManager().addSpectator(player, target);
        return true;
    }
}
