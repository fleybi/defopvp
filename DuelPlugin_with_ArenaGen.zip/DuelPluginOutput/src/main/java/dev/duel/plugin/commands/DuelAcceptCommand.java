package dev.duel.plugin.commands;

import dev.duel.plugin.DuelPlugin;
import dev.duel.plugin.util.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class DuelAcceptCommand implements CommandExecutor {
    private final DuelPlugin plugin;
    public DuelAcceptCommand(DuelPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;
        plugin.getDuelManager().acceptRequest(player);
        return true;
    }
}
