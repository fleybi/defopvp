package dev.duel.plugin.commands;

import dev.duel.plugin.DuelPlugin;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class DuelDenyCommand implements CommandExecutor {
    private final DuelPlugin plugin;
    public DuelDenyCommand(DuelPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;
        plugin.getDuelManager().denyRequest(player);
        return true;
    }
}
