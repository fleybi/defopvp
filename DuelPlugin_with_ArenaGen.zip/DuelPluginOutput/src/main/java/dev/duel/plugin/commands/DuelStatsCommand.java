package dev.duel.plugin.commands;

import dev.duel.plugin.DuelPlugin;
import dev.duel.plugin.stats.PlayerStats;
import dev.duel.plugin.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.UUID;

public class DuelStatsCommand implements CommandExecutor {
    private final DuelPlugin plugin;
    public DuelStatsCommand(DuelPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        UUID target;
        String name;

        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Usage: /duelstats <player>");
                return true;
            }
            target = player.getUniqueId();
            name = player.getName();
        } else {
            Player p = Bukkit.getPlayerExact(args[0]);
            if (p == null) {
                MessageUtil.send(sender, "&cPlayer not found. They must be online.");
                return true;
            }
            target = p.getUniqueId();
            name = p.getName();
        }

        PlayerStats stats = plugin.getStatsManager().getStats(target);

        MessageUtil.sendRaw(sender, "&8&m------------------------");
        MessageUtil.sendRaw(sender, " &c&lStats &7for &e" + name);
        MessageUtil.sendRaw(sender, "&8&m------------------------");
        MessageUtil.sendRaw(sender, "  &7ELO: &e" + stats.getElo());
        MessageUtil.sendRaw(sender, "  &7Wins: &a" + stats.getWins() + " &8| &7Losses: &c" + stats.getLosses());
        MessageUtil.sendRaw(sender, "  &7Win Rate: &e" + String.format("%.1f", stats.getWinRate()) + "%");
        MessageUtil.sendRaw(sender, "  &7K/D: &e" + String.format("%.2f", stats.getKDR()));
        MessageUtil.sendRaw(sender, "&8&m------------------------");
        return true;
    }
}
