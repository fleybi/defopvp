package dev.duel.plugin.commands;

import dev.duel.plugin.DuelPlugin;
import dev.duel.plugin.kit.KitType;
import dev.duel.plugin.util.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class QueueCommand implements CommandExecutor {
    private final DuelPlugin plugin;
    public QueueCommand(DuelPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        KitType kit = KitType.NODEBUFF;
        if (args.length >= 1) {
            kit = KitType.fromString(args[0]);
            if (kit == null) {
                MessageUtil.send(player, "&cUnknown kit. Try: nodebuff, diamond, uhc, sumo, builduhc, boxing");
                return true;
            }
        } else {
            // Show kit list
            StringBuilder sb = new StringBuilder();
            for (KitType k : plugin.getKitManager().getEnabledKits()) {
                int count = plugin.getQueueManager().getQueueSize(k);
                if (sb.length() > 0) sb.append("\n");
                sb.append("  ").append(k.getDisplayName()).append(" &8- &7").append(count).append(" in queue &8[&7/queue ").append(k.getId()).append("&8]");
            }
            MessageUtil.send(player, "&7Available queues:");
            MessageUtil.sendRaw(player, sb.toString());
            return true;
        }

        plugin.getQueueManager().joinQueue(player, kit);
        return true;
    }
}
