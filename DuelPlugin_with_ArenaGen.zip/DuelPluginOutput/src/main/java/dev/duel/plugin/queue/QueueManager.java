package dev.duel.plugin.queue;

import dev.duel.plugin.DuelPlugin;
import dev.duel.plugin.kit.KitType;
import dev.duel.plugin.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;

public class QueueManager {

    private final DuelPlugin plugin;
    private final Map<KitType, Queue<UUID>> queues = new HashMap<>();
    private final Map<UUID, KitType> playerKitMap = new HashMap<>();

    public QueueManager(DuelPlugin plugin) {
        this.plugin = plugin;
        for (KitType kit : KitType.values()) {
            queues.put(kit, new LinkedList<>());
        }
        startMatchmakingTask();
    }

    public void joinQueue(Player player, KitType kit) {
        if (plugin.getDuelManager().isInDuel(player.getUniqueId())) {
            MessageUtil.send(player, "&cYou are already in a duel!");
            return;
        }
        if (isInQueue(player.getUniqueId())) {
            MessageUtil.send(player, "&cYou are already in a queue! &7/leavequeue");
            return;
        }

        queues.get(kit).add(player.getUniqueId());
        playerKitMap.put(player.getUniqueId(), kit);

        int count = queues.get(kit).size();
        MessageUtil.send(player, "&aYou joined the " + kit.getDisplayName() + " &aqueue! Players in queue: &e" + count);
    }

    public void leaveQueue(Player player) {
        KitType kit = playerKitMap.remove(player.getUniqueId());
        if (kit == null) {
            if (plugin.getDuelManager().isSpectating(player.getUniqueId())) {
                plugin.getDuelManager().removeSpectator(player);
                MessageUtil.send(player, "&7You stopped spectating.");
            } else {
                MessageUtil.send(player, "&cYou are not in a queue.");
            }
            return;
        }
        queues.get(kit).remove(player.getUniqueId());
        MessageUtil.send(player, "&cYou left the queue.");
    }

    public boolean isInQueue(UUID uuid) {
        return playerKitMap.containsKey(uuid);
    }

    public KitType getQueuedKit(UUID uuid) {
        return playerKitMap.get(uuid);
    }

    public int getQueueSize(KitType kit) {
        return queues.get(kit).size();
    }

    private void startMatchmakingTask() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (KitType kit : KitType.values()) {
                Queue<UUID> queue = queues.get(kit);
                while (queue.size() >= 2) {
                    UUID uuid1 = queue.poll();
                    UUID uuid2 = queue.poll();

                    playerKitMap.remove(uuid1);
                    playerKitMap.remove(uuid2);

                    Player p1 = Bukkit.getPlayer(uuid1);
                    Player p2 = Bukkit.getPlayer(uuid2);

                    if (p1 == null || !p1.isOnline()) {
                        if (p2 != null && p2.isOnline()) {
                            queue.add(uuid2);
                            playerKitMap.put(uuid2, kit);
                        }
                        continue;
                    }
                    if (p2 == null || !p2.isOnline()) {
                        queue.add(uuid1);
                        playerKitMap.put(uuid1, kit);
                        continue;
                    }

                    plugin.getDuelManager().startDuel(p1, p2, kit);
                }
            }
        }, 20L * 2, 20L * 2);
    }
}
